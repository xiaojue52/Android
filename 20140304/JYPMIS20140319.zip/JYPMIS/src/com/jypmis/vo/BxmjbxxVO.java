package com.jypmis.vo;

public class BxmjbxxVO {
	public String xmid;
	public String xmbx;
	public String xmmc;
	public String xmjc;
	public String xmlx;
	public String zrbm;
	public String xmjl;
	public String cpx;
	public String zcpx;
	public String ksrq;
	public String jsrq;
	public String xsfzr;
	public String sqgcs;
	public String khmc;
	public String khfzr;
	public String lxfs;
	public String yjrs;
	public String gq;
	public String rgcb;
	public String qtjjfy;
	public String sfxcp;
	public String xmjb;
	public String xmjs;
	/*
	 * 同步标示
	 */
	public String identifier;
	
}

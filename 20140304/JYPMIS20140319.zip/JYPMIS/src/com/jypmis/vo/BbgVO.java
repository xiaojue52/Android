package com.jypmis.vo;

public class BbgVO {
	public String bgid;
	public String bgxid;//报工项id
	public String xmid;
	public String xmjc;//新增的属性，数据库中无
	public String gzrq;
	public String gzxs;
	public String gzdd;
	public String gznr;
	public String bgr;//人名
	public String bgsj;
	public String zt;
	public String shr;//人名
	public String shsj;
	public String shxx;
	/**
	 * 真实位置
	 */
	public String zswz;
}

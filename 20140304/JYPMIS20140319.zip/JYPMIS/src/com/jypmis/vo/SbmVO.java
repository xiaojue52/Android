package com.jypmis.vo;

public class SbmVO {
	public String bmid;
	public String bmmc;
	public String bmjc;
	public String bmlx;
	public String zt;
	public String bz;
	public String bmzr;
	public String bmbh;
}

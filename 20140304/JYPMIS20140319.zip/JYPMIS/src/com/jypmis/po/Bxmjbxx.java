package com.jypmis.po;
/**
 * 项目基本信息
 *
 */
public class Bxmjbxx {
	public String xmid;
	public String xmbx;
	public String xmmc;
	public String xmjc;
	public String xmlx;
	public String zrbm;
	public String xmjl;
	public String cpx;
	public String zcpx;
	public String ksrq;
	public String jsrq;
	public String xsfzr;
	public String sqgcs;
	public String khmc;
	public String khfzr;
	public String lxfs;
	public String yjrs;
	public String gq;
	public Float rgcb;
	public Float qtjjfy;
	public String sfxcp;
	public String xmjb;
	public String xmjs;
	
	public String getXmid() {
		return xmid;
	}
	public void setXmid(String xmid) {
		this.xmid = xmid;
	}
	public String getXmbx() {
		return xmbx;
	}
	public void setXmbx(String xmbx) {
		this.xmbx = xmbx;
	}
	public String getXmmc() {
		return xmmc;
	}
	public void setXmmc(String xmmc) {
		this.xmmc = xmmc;
	}
	public String getXmjc() {
		return xmjc;
	}
	public void setXmjc(String xmjc) {
		this.xmjc = xmjc;
	}
	public String getXmlx() {
		return xmlx;
	}
	public void setXmlx(String xmlx) {
		this.xmlx = xmlx;
	}
	public String getZrbm() {
		return zrbm;
	}
	public void setZrbm(String zrbm) {
		this.zrbm = zrbm;
	}
	public String getXmjl() {
		return xmjl;
	}
	public void setXmjl(String xmjl) {
		this.xmjl = xmjl;
	}
	public String getCpx() {
		return cpx;
	}
	public void setCpx(String cpx) {
		this.cpx = cpx;
	}
	public String getZcpx() {
		return zcpx;
	}
	public void setZcpx(String zcpx) {
		this.zcpx = zcpx;
	}
	public String getKsrq() {
		return ksrq;
	}
	public void setKsrq(String ksrq) {
		this.ksrq = ksrq;
	}
	public String getJsrq() {
		return jsrq;
	}
	public void setJsrq(String jsrq) {
		this.jsrq = jsrq;
	}
	public String getXsfzr() {
		return xsfzr;
	}
	public void setXsfzr(String xsfzr) {
		this.xsfzr = xsfzr;
	}
	public String getSqgcs() {
		return sqgcs;
	}
	public void setSqgcs(String sqgcs) {
		this.sqgcs = sqgcs;
	}
	public String getKhmc() {
		return khmc;
	}
	public void setKhmc(String khmc) {
		this.khmc = khmc;
	}
	public String getKhfzr() {
		return khfzr;
	}
	public void setKhfzr(String khfzr) {
		this.khfzr = khfzr;
	}
	public String getLxfs() {
		return lxfs;
	}
	public void setLxfs(String lxfs) {
		this.lxfs = lxfs;
	}
	public String getYjrs() {
		return yjrs;
	}
	public void setYjrs(String yjrs) {
		this.yjrs = yjrs;
	}
	public String getGq() {
		return gq;
	}
	public void setGq(String gq) {
		this.gq = gq;
	}
	public Float getRgcb() {
		return rgcb;
	}
	public void setRgcb(Float rgcb) {
		this.rgcb = rgcb;
	}
	public Float getQtjjfy() {
		return qtjjfy;
	}
	public void setQtjjfy(Float qtjjfy) {
		this.qtjjfy = qtjjfy;
	}
	public String getSfxcp() {
		return sfxcp;
	}
	public void setSfxcp(String sfxcp) {
		this.sfxcp = sfxcp;
	}
	public String getXmjb() {
		return xmjb;
	}
	public void setXmjb(String xmjb) {
		this.xmjb = xmjb;
	}
	public String getXmjs() {
		return xmjs;
	}
	public void setXmjs(String xmjs) {
		this.xmjs = xmjs;
	}
	
}

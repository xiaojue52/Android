package com.jypmis.vo;

public class SxtyhVO {
	public String yhid;
	public String bmid;
	public String gwid;
	public String wbdwid;
	public String yhxm;
	public String sjhm;
	public String dlkl;
	public String zt;
	public String bz;
	public String shqx;
}

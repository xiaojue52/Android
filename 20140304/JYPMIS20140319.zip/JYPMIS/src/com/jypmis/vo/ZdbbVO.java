package com.jypmis.vo;

public class ZdbbVO {

	public String zdbbid;
	public String ptlx;
	public String bbh;
	public String wjdx;
}

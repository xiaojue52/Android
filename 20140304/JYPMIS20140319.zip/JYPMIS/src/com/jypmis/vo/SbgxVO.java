package com.jypmis.vo;

public class SbgxVO {
	public String bgxid;
	public String bgxmc;
	public String glbm;
	public String zt;
}
